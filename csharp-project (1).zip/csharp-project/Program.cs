//1
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var telebeler = new Dictionary<int, string>{
            {1,"Ibis"},{2,"Okuc"},{3,"Sari"},{4,"Yusif"},{5,"wiki"}
        };
        while(true){
            Console.Write("\n1)elave et 2)id le axtar 3)goster 4)cixis\n secin:");
            string secin=Console.ReadLine();
            if(secin=="4") break;
            switch(secin)
            {
                case "1":
                    Console.Write("ID: "); int id=int.Parse(Console.ReadLine());
                    Console.Write("Ad: "); telebeler[id] = Console.ReadLine();
                    Console.WriteLine("Əlavə olundu!");
                    break;
                    
                case "2":
                    Console.Write("Axtarılan ID: "); int axtarId=int.Parse(Console.ReadLine());
                    Console.WriteLine(telebeler.ContainsKey(axtarId) ? $"Ad: {telebeler[axtarId]}" : "Tapılmadı!");
                    break;
                    
                case "3":
                    foreach (var t in telebeler) Console.WriteLine($"ID: {t.Key} - Ad: {t.Value}");
                    break;
                    
                default:
                    Console.WriteLine("Yanlis secim");
                    break;
            }
        }            
    }
}

//2
    using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {  
        Console.WriteLine("Fiqur secin: daire  duzbucaqli  ucbucaq");
        Console.Write("Seciminiz: ");
        string secim = Console.ReadLine().ToLower().Trim();
        
        double sahe = 0;

        switch(secim){
            case "daire":
                Console.Write("Radiusu daxil edin: ");
                double r = double.Parse(Console.ReadLine());
                sahe = Math.PI * Math.Pow(r, 2);
                break;

            case "duzbucaqli": 
                Console.Write("Enini daxil edin: ");
                double a = double.Parse(Console.ReadLine());
                Console.Write("Uzunlugu daxil edin: ");
                double b = double.Parse(Console.ReadLine());
                sahe = a * b;
                break;
            
            case "ucbucaq":
                Console.WriteLine("Ucbucagin tereflerini daxil edin:");
                Console.Write("a terefi: "); double t1 = double.Parse(Console.ReadLine());
                Console.Write("b terefi: "); double t2 = double.Parse(Console.ReadLine());
                Console.Write("c terefi: "); double t3 = double.Parse(Console.ReadLine());
                
                
                double p = (t1 + t2 + t3) / 2;
                sahe = Math.Sqrt(p * (p - t1) * (p - t2) * (p - t3));
                break;

            default:
                Console.WriteLine("Yanlis secim!");
                return;
        } 

        double yuvarlaqSahe = Math.Round(sahe, 2);
        Console.WriteLine($"\nSecilmis fiqurun sahesi: {yuvarlaqSahe}");
    }
}

//3
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> ededler = new List<int>();

        Console.WriteLine("10 eded daxil edin:");
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"{i + 1}-ci ededi daxil edin: ");
            int eded = int.Parse(Console.ReadLine());
            ededler.Add(eded);
        }
        int enBoyuk = ededler[0];
        int enKicik = ededler[0];

        int cutSay = 0;
        int tekSay = 0;
        foreach (int eded in ededler)
        {
            enBoyuk = Math.Max(enBoyuk, eded);
            enKicik = Math.Min(enKicik, eded);
            if (eded % 2 == 0)
            {
                cutSay++;
            }
            else
            {
                tekSay++;
            }
        }
        Console.WriteLine($"en boyuk eded: {enBoyuk}");
        Console.WriteLine($"en kicik eded: {enKicik}");
        Console.WriteLine($"cut ededlerin sayi: {cutSay}");
        Console.WriteLine($"Tek ededlerin sayi sayi: {tekSay}");
    }
}

//4
using System;
class Program
{
    static void Main()
    {
        Random random = new Random();
        int gizliEded = random.Next(0, 101);
        int texmin;
        int cehdSayi = 0;
        int minAraliq = 0;
        int maxAraliq = 100;
        Console.WriteLine("0-100 arasi eded yaz");
        do
        {
            int optimalTeqribi = (minAraliq + maxAraliq) / 2;
            Console.WriteLine($"[daha tez: {optimalTeqribi}]");

            Console.Write("Texmininizi daxil edin: ");
            texmin = int.Parse(Console.ReadLine());
            cehdSayi++; 
            if (texmin > gizliEded)
            {
                Console.WriteLine("Daha kicik eded yazin");
                maxAraliq = texmin - 1;
            }
            else if (texmin < gizliEded)
            {
                Console.WriteLine("Daha boyuk eded yazin");
                minAraliq = texmin + 1;
            }
            else
            {
                Console.WriteLine($"\n Tebrikler");
                Console.WriteLine($"umumi cehd sayi: {cehdSayi}");
            }
            Console.WriteLine(); 
        } while (texmin != gizliEded);
    }
}
